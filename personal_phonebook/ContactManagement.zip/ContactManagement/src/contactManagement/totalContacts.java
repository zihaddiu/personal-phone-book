
package contactManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class totalContacts extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    public totalContacts() {
        super("Contact List");
        initComponents();
        this.setLocationRelativeTo(null);
        loadDat();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnback = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblcontacts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 204));

        btnback.setBackground(new java.awt.Color(153, 153, 153));
        btnback.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnback.setText("back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });

        tblcontacts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "PhoneNo", "Email", "Street", "City", "Zip Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblcontacts);
        if (tblcontacts.getColumnModel().getColumnCount() > 0) {
            tblcontacts.getColumnModel().getColumn(0).setResizable(false);
            tblcontacts.getColumnModel().getColumn(1).setResizable(false);
            tblcontacts.getColumnModel().getColumn(2).setResizable(false);
            tblcontacts.getColumnModel().getColumn(3).setResizable(false);
            tblcontacts.getColumnModel().getColumn(4).setResizable(false);
            tblcontacts.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(btnback)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnback))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
        // TODO add your handling code here:
        adminSelectItem obj= new adminSelectItem();
        obj.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnbackActionPerformed

        public void loadDat(){
        try{
             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
             String URL = "jdbc:sqlserver://localhost:1433;databaseName=contactmanagement;user=sa;password=123";
             Connection conn = DriverManager.getConnection(URL);
//             Statement st = null;
//             st = conn.createStatement();
             
             
             String sql="select *from contact";
             
             //String username=localName;
             
             pst=conn.prepareStatement(sql);
             rs=pst.executeQuery(); 
            
            while(rs.next()){
                String name=rs.getString("name");
                String phoneno= rs.getString("phoneno");
                String email= rs.getString("email");
                String street= rs.getString("street");
                String city= rs.getString("city");
                String zipcode= rs.getString("zipcode");
                
                Object[] objs = { name,phoneno, email,street,city,zipcode};

                DefaultTableModel model = (DefaultTableModel) tblcontacts.getModel();

                model.addRow(objs);
            }
             rs.close();
            pst.close();
        }catch(ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new totalContacts().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnback;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblcontacts;
    // End of variables declaration//GEN-END:variables
}
