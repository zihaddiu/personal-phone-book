package contactManagement;
import java.sql.*;
import javax.swing.JOptionPane;
public class ConnectionClass 
{
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    public static void main(String[] args) throws ClassNotFoundException 
   
    {
        connect();
    }
    
    public static Connection connect(){
        try 
        {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String URL = "jdbc:sqlserver://localhost:1433;databaseName=contactmanagement;user=sa;password=123";
        Connection conn = DriverManager.getConnection(URL);
          //  System.out.println("connection hyce");
         return conn;
        }
        catch (ClassNotFoundException | SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.toString());
            return null;
        }
    }
}
